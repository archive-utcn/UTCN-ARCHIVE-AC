perm(L, [H|R]):-append(A, [H|T], L), append(A, T, L1), perm(L1, R).
perm([], []).


takeout(X,[X|R],R).
takeout(X,[F|R],[F|S]) :- takeout(X,R,S).


perm2([H|T],R):- perm2(T, L),takeout(H, R, L).
perm2([], []).

max1([H|T], M) :- max1(T, M),M>H,!.
max1([H|_], H).


sel_sort(L, [M|R]):- max1(L, M), delete(L, M, L1), sel_sort(L1, R).
sel_sort([], []).