add2(X, LS, LE, RS, RE):- RS = LS, LE = [X|RE].

il_to_dl([L], L, L) :- var(L), !.
il_to_dl([H|T], RS, RE) :- add2(H, RS, RE, NRS, NRE),
    					   il_to_dl(T, NRS, NRE).

dl_to_il(LS, _, [_]) :- var(LS), !.
dl_to_il([H|LS], LE, [H|R]) :- dl_to_il(LS, LE, R).

cl_to_dl([], L, L) :- !.
cl_to_dl([H|T], RS, RE) :- add2(H, RS, RE, NRS, NRE),
    					   cl_to_dl(T, NRS, NRE).

dl_to_cl(LS, _, []) :- var(LS), !.
dl_to_cl([H|LS], LE, [H|R]) :- dl_to_cl(LS, LE, R).


flat_dl([], R, R).
flat_dl([H|T], [H|LS], LE) :- atomic(H), !, flat_dl(T, LS, LE).
flat_dl([H|T], LS, LE) :- flat_dl(H, LS, Aux), flat_dl(T, Aux, LE).



tree1(t(6, t(4,t(2,nil,nil),t(5,nil,nil)), t(9,t(7,nil,nil),nil))).