member(X, [X|_]) :- !.
member(X, [_|T]) :- member(X, T).



inters(L, L, L).
inters([], _, []).
inters([H|T], L2, [H|R]) :- member(H, L2),!,inters(T, L2, R).
inters([_|T], L2, R) :- inters(T,L2,R).

diff([], _, []).
diff(L, L, []).
diff([H|T], L2, R) :- member(H, L2),!,diff(T, L2, R).
diff([H|T], L2, [H|R]) :- diff(T,L2,R).

delete(X, [X|T], R) :- !, delete(X, T, R).
delete(X, [H|T], [H|R]) :- !, delete(X, T, R).
delete(_, [], []).

min1([H|T], M) :- min1(T, M), M<H, !.
min1([H|_], H).

del_min([], []).
del_min([], _).
del_min([H|T], R) :- min1([H|T], M),delete(M, [H|T], R).

max1([H|T], M) :- max1(T, M),M>H,!.
max1([H|_], H).

del_max([], []).
del_max([], _).
del_max([H|T], R) :- max1([H|T], M),delete(M, [H|T], R).


reverse2([], Acc, R) :- Acc=R.
reverse2([H|T], Acc, R) :- Acc1=[H|Acc], reverse2(T, Acc1, R).
reverse2_pretty(L, R) :- reverse2(L, [], R).

reverse_k([], _, []).
reverse_k([H|T], 0, R) :- !, reverse2_pretty([H|T], R).
reverse_k([H|T], K, [H|R]) :- KN is K-1,reverse_k(T, KN, R).


rle_encode([], []).
rle_encode(L, R) :- rle_encode(L, R, 1).
rle_encode([H], [H, Count], Count) :- !.
rle_encode([H1, H2|T], R, Count) :- H1 is H2,!,NCount is Count+1,rle_encode([H2|T], R, NCount).
rle_encode([H1, _|T], [[H1, Count]|R], Count) :- rle_encode(T, R, 1).
