
uniq1([],[]).
uniq1([H|T], [H|R]) :-  uniq1(T, R), not(member(H,R)),!.
uniq1([_|T], R):- uniq1(T, R).

uniq2([],R,R).
uniq2([H|T],Acc,R):- not(member(H,Acc)),!,uniq2(T,[H|Acc],R).
uniq2([_|T],Acc,R):- uniq2(T,Acc,R).