tree1(t(6, t(4,t(2,nil,nil),t(5,nil,nil)), t(9,t(7,nil,nil),nil))).
tree2(t(8, t(5, nil, t(7, nil, nil)), t(9, nil, t(11, nil, nil)))).
	
tree4(t(6, t(4,t(2,nil,nil),nil), t(9,t(7,nil,nil),nil))).
tree5(t(6, t(4,nil,t(5,nil,nil)), t(9,t(7,nil,nil),nil))).

tree3(t(6, t(4, t(2, nil, nil, nil), nil, t(7, nil, nil, nil)), t(5,nil,nil,nil), t(9, t(3,nil,nil,nil), nil, nil))).

pretty_print(nil, _).
pretty_print(t(K,L,R), D):-D1 is D+1,
							pretty_print(R, D1), 
							print_key(K, D), 
							pretty_print(L, D1). 
% predicat care afișează cheia K la D tab-uri față de marginea din stânga și inserează o linie nouă
print_key(K, D):-D>0, !, D1 is D-1, write('\t'), print_key(K, D1).
print_key(K, _):-write(K), write('\n').
% write('\n') îi echivalent cu predicatul nl

pretty_print(T) :- pretty_print(T,0).


%pretty print ternary tree

print_key1(K, D, 0):-D>0, !, D1 is D-1, write('\t'), print_key1(K, D1, 0).
print_key1(K, D, 1):-D>0, !, D1 is D-1, write('\t'), print_key1(K, D1, 1).
print_key1(K, _, 0):-write(K), write('\n').
print_key1(K, _, 1):-write(K).

pretty_print2(nil, _, _).			
pretty_print2(t(K,L,M,R), D, Flag):-D1 is D+1,
								pretty_print2(R, D1, 0), 
								print_key1(K, D, Flag), 
								pretty_print2(M, D1, 1),
								write('\n'),
								pretty_print2(L, D1, 0).
							
							
pretty_print2(T) :- pretty_print2(T,0,1).
		


ternary_inorder(t(K,L,M,R), List):- ternary_inorder(L,LL), ternary_inorder(M,LM), ternary_inorder(R,LR), append(LM, LR , List1),
																										 append(LL,[K|List1],List).
ternary_inorder(nil, []).


ternary_preorder(t(K,L,M,R), List):- ternary_preorder(L,LL), ternary_preorder(M,LM), ternary_preorder(R,LR), append(LM, LR , List1),
																										 append([K|LL],List1,List).
ternary_preorder(nil, []).


ternary_postorder(t(K,L,M,R), List):- ternary_postorder(L,LL), ternary_postorder(M,LM), ternary_postorder(R,LR), append(LR, [K] , List1),
																										 append(LM,List1,List2),
																										 append(LL,List2,List).
ternary_postorder(nil, []).



max(X,Y,X):- X>Y,!.				%maxim-ul meu.
max(_,Y,Y).

ternary_height(nil, 0).
ternary_height(t(_, L, M, R), H):-ternary_height(L, H1),
								ternary_height(M, H2),
							    ternary_height(R, H3),
								max(H1, H2, H4),
								max(H3, H4, H5),
								H is H5+1.


delete_key(Key, t(Key, L, nil), L):-!.
delete_key(Key, t(Key, nil, R), R):-!.
delete_key(Key, t(Key, L, R), t(Pred,NL,R)):-!,get_pred(L,Pred,NL).
delete_key(Key, t(K,L,R), t(K,NL,R)):-Key<K,!,delete_key(Key,L,NL).
delete_key(Key, t(K,L,R), t(K,L,NR)):-delete_key(Key,R,NR).

% caută nodul predecesor
get_pred(t(Pred, L, nil), Pred, L):-!.
get_pred(t(Key, L, R), Pred, t(Key, L, NR)):-get_pred(R, Pred, NR).



delete_key2(Key, t(Key, L, nil), L):-!.
delete_key2(Key, t(Key, nil, R), R):-!.
delete_key2(Key, t(Key, L, R), t(Succ,L,NR)):-!,get_succ(R,Succ,NR).
delete_key2(Key, t(K,L,R), t(K,NL,R)):-Key<K,!,delete_key2(Key,L,NL).
delete_key2(Key, t(K,L,R), t(K,L,NR)):-delete_key2(Key,R,NR).

% caută nodul s
get_succ(t(Succ, nil, R), Succ, R):-!.
get_succ(t(Key, L, R), Succ, t(Key, NL, R)):-get_succ(L, Succ, NL).



height(nil, 0).
height(t(_, L, R), H):-height(L, H1), 
					 height(R, H2),
					 max(H1, H2, H3), 
					 H is H3+1.
					 
					 
leafs(t(K,nil,nil), [K]):- !.
leafs(t(_,L,R), List):-leafs(L,LL), leafs(R,LR), 
						append(LL, LR, List).
leafs(nil, []).


diameter(t(_,L,R), Diameter):-diameter(L,LL), diameter(R,LR), 
							max(LL, LR, Diameter1),
							height(L,HL),
							height(R,HR),
							H is HL+HR+1,
							max(Diameter1,H,Diameter).
diameter(nil, 0).


same_height(t(K,L,R),H, [K]):-height(t(K,L,R),Height), Height = H, !.
same_height(t(_,L,R),H, List):-same_height(L,H,LL), same_height(R,H,LR), 
						append(LL, LR, List).
same_height(nil,_, []).

every_same_height(t(K,L,R),H,[[[H]|R1]|R2]):- H>0, !, same_height(t(K,L,R),H,R1), H1 is H-1, every_same_height(t(K,L,R),H1,R2).
every_same_height(_,_,[]).

every_same_height_pretty(t(K,L,R),Result) :- height(t(K,L,R),H), every_same_height(t(K,L,R),H,Result).


symmetric(t(_,L,R)):- symmetrical(L,R).

symmetrical(nil,nil).
symmetrical(t(_,L1,R1),t(_,L2,R2)) :- symmetrical(L1,R2), symmetrical(R1,L2).


min(t(K,nil,_), K).
min(t(K,L,R),M):-min(L,M).