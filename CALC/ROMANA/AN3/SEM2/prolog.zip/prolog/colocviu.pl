  /*
You are given a complete list where every element is a leaf node ( t(K, nil, nil) ). Traverse the elements of the list and create an incomplete BST from them.
E.g. ? to_bst([t(10, nil, nil), t(5, nil, nil), t(15, nil, nil), t(1, nil, nil), t(8, nil, nil), t(20, nil, nil)], R).
R = t(10, t(5, t(1, _, _), t(8, _, _)), t(15, _, t(20, _, _))).
*/

to_bst([t(Key, _, _)|T],R):- to_bst(T, t(Key, _, _),R).

to_bst([],R,R).
to_bst([t(Key, _, _)|T], AccTree,R):- insert_it(Key,AccTree),to_bst(T,AccTree,R).

insert_it(Key, t(Key, _, _)):-!.
insert_it(Key, t(K, L, R)):-Key<K, !, insert_it(Key, L).
insert_it(Key, t(_, _, R)):-insert_it(Key, R).