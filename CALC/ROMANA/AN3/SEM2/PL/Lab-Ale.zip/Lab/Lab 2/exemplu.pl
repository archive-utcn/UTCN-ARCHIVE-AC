cmmdc(X,X,X).
cmmdc(X,Y,Z):- X>Y, R is X-Y, cmmdc(R,Y,Z).
cmmdc(X,Y,Z):- X<Y, R is Y-X, cmmdc(X,R,Z).

factorial_b(1,1).
factorial_b(N,R):- N>1, N1 is N-1, factorial_b(N1,R1), R is R1*N.

factorial_f(1,PR,PR).
factorial_f(N,PR,R):- N>1, N1 is N-1, PRI is PR*N, factorial_f(N1,PRI,R).
 
cmmmc(X,Y,Z):- cmmdc(X,Y,Z1), P is X*Y, Z is P/Z1.

fibonacci(1,1).  
fibonacci(2,1).
fibonacci(N,R):- N>2, N1 is N-1, N2 is N-2, fibonacci(N1,R1), fibonacci(N2,R2), R is R1+R2.

triangle(A,B,C):- A+B > C, B+C > A, A+C > B.

solve_eq(X,A,B,C):- D is B*B-4*A*C, X is (-B+sqrt(D))/(2*A).
solve_eq(X,A,B,C):- D is B*B-4*A*C, X is (-B-sqrt(D))/(2*A).

while(B,B):- write(B).
while(A,B):- A<B, write(A), write(' '), C is A+1, while(C,B).

power_b(X,Y,Y,X).
power_b(X,Y,PR,Z):- PR<Y, PR1 is PR+1, power_b(X,Y,PR1,Z1), Z is X*Z1.

power_f(_,0,PR,PR). % power_f(X,0,PR,PR).
power_f(X,Y,PR,Z):- Y>0, Y1 is Y-1, PR1 is PR*X, power_f(X,Y1,PR1,Z). 