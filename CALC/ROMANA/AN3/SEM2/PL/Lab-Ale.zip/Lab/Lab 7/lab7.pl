tree1(t(6, t(4,t(2,_,_),t(5,_,_)), t(9,t(7,_,_),_))).

member_il(_, L):-var(L), !, fail.
member_il(X, [X|_]):-!.
member_il(X, [_|T]):-member_il(X, T).

insert_il(X,V):-var(V),!,V=[X|_].
insert_il(X,[X|_]):-!.
insert_il(X,[_|T]):-insert_il(X,T).

search_it(X,V):-var(V),!,fail.
search_it(X,t(X,_,_)):-!.
search_it(X,t(K,L,_)):-X<K,!,search_it(X,L).
search_it(X,t(_,_,R)):-search_it(X,R).

append_il(V,L2,L2):-var(V),!.
append_il([H1|T1],L2,[H1|L]):-append_il(T1,L2,L).

preord_il(V,_):-var(V),!.
preord_il(t(K,L,R),LF):-preord_il(L,Lista1),append_il(Lista1,[K|_],Lista2),preord_il(R,Lista3),append_il(Lista2,Lista3,LF).

max(A,B,C):- A>B,!, C is A.
max(_,B,C):- C is B. 

height_il(V, -1):-var(V),!.
height_il(t(_, L, R), H):-height_il(L, H1), height_il(R, H2), max(H1, H2, H3), H is H3+1.

%flatten(V,[_]):-var(V).
%flatten([H|T], [H|R]):- atomic(H), !, flatten(T,R).
%flatten([H|T], R):- flatten(H,R1), flatten(T,R2), append_il(R1,R2,R).