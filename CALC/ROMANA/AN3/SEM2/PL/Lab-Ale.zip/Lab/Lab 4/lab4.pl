minim([],PM,PM).
minim([H|T],PM,M):-H<PM, !, minim(T,H,M).
minim([_|T],PM,M):-minim(T,PM,M).

inters([],L2,[]).
inters([H1|T1],L2,R):-member(H1,L2),!,inters(T1,L2,R1),append(R1,[H1],R).
inters([H|T],L2,R):-inters(T,L2,R).

delete_all(X,[],[]).
delete_all(X,[X|T],R):-delete_all(X,T,R).
delete_all(X,[H|T],[H|R]):-X\=H, delete_all(X,T,R).

del_min(L,R):-minim(L,10000,MIN),delete_all(MIN,L,R).

separa([],_,_,[],[]).
separa([H|T],I,K,L1,L2):- I1 < K,!,I1 is I+1, separa(T,I1,K,L11,L2),append([H],L11,L1).
separa([H|T],I,K,L1,L2):- I1 is I+1, separa(T,I1,K,L1,L22),append(L22,[H],L2).  
reverse_k(L,K,R):-separa(L,1,K,L1,L2),append(L1,L2,R).

select([H|_],N,N,H).
select([H|T],C,N,R):- C2 is C+1, select(T,C2,N,R).
select(L,N,R):-select(L,1,N,R).
rnd_select(_,K,K,[]).
rnd_select(L,N,K,[X|PR]):-length(L,Len), Rnd is random(Len), select(L,Rnd,X), delete(X,L,L2),N2 is N+1,, rnd_select(L2,N2,K,PR).