:- dynamic node/1.
:- dynamic edge/2.
:- dynamic neighbor/2.

node(a). node(b). node(c). node(d).

edge(a,b). edge(b,a).
edge(b,c). edge(c,b).
edge(b,d). edge(d,b).

edge_to_neigh:- retract(node(X)),!,process(X,L),assert(neighbor(X,L)),edge_to_neigh.
edge_to_neigh.

process(X,L):- findall(Y,edge(X,Y),L).
