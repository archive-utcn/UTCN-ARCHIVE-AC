delete_all(X,[],[]).
delete_all(X,[X|T],R):-delete_all(X,T,R).
delete_all(X,[H|T],[H|R]):-X\=H, delete_all(X,T,R).

append3(L1,L2,L3,R):- append(L2,L3,R1), append(L1,R1,R).

add_first(X,L,R):- append([X],L,R).

suma([],0).
suma([H|T],R):-suma(T,R1), R is H+R1.

separate_parity([],[],[]).
separate_parity([H|T],[H|E],O):- 0 is H mod 2 , separate_parity(T,E,O).
separate_parity([H|T],E,[H|O]):- 1 is H mod 2, separate_parity(T,E,O).

remove_duplicates([],[]).
remove_duplicates([H|T],R):- member(H,T), remove_duplicates(T,R).
remove_duplicates([H|T],[H|R]):- remove_duplicates(T,R).

replace_all(_,_,[],[]).
replace_all(X,Y,[X|T],[Y|R]):-replace_all(X,Y,T,R).
replace_all(X,Y,[H|T],[H|R]):-X\=H, replace_all(X,Y,T,R).

drop_k1([],_,_,[]).
drop_k1([H|T],X,I,R):- 0 is I mod X, I1 is I+1, drop_k1(T,X,I1,R). 
drop_k1([H|T],X,I,[H|R]):- I1 is I+1, drop_k1(T,X,I1,R).
drop_k(L,X,R):-drop_k1(L,X,1,R).