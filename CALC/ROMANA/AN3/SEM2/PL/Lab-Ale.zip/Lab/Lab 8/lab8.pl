flatten([],RS,RS):-!.
flatten([H|T],RS,RE):- atomic(H), !, flatten(T,L1S,L1E),RS=[H|L1S],RE=L1E.
flatten([H|T],RS,RE):- flatten(H,L1S,L1E), flatten(T,L2S,L2E), RS=L1S,L2S=L1E,RE=L2E.