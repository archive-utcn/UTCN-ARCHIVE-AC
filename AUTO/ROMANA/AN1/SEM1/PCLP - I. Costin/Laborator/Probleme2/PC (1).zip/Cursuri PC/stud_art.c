#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define MAX 100
#define N 60

typedef struct {
  char name[N];
  float average;
} StudentT;

void sort(const char filename[], const char sorted_filename[]) {
  typedef struct {
    long nb;
    float average;
  } ElementT;

  typedef enum {
      FALSE, TRUE
  } BooleanT;

  ElementT el, t[MAX];
  int i, j, n;
  FILE *fd1, *fd2;
  BooleanT flag;
  StudentT stu;

  /* read file to array t */
  j = 0;
  fd1 = fopen(filename, "rb");
  while ( fread(&stu, sizeof(stu), 1, fd1) > 0 && j < MAX) {
    t[j].nb = j;
    t[j].average = stu.average;
    j++;
  }
  n = j;

  /* sort array t by average */
  j = 0;
  do {
    flag = TRUE;
    for (i = 1; i < n - j ; i++)
      if (t[i-1].average < t[i].average) {
        memcpy(&el, &t[i-1], sizeof(ElementT));
        memcpy(&t[i-1], &t[i], sizeof(ElementT));
        memcpy(&t[i], &el, sizeof(ElementT));
        flag = FALSE;
      }
  } while (flag == FALSE);

  /* write sorted output */
  if ((fd2 = fopen(sorted_filename, "wb")) < 0) {
    printf("\nCannot create %s. ", sorted_filename);
    getchar();
    exit(1);
  }
  for (i=0; i<n; i++) {
    fseek(fd1, (long)(t[i].nb * sizeof(stu)), SEEK_SET);
    fread(&stu, sizeof(stu), 1, fd1);
    fwrite(&stu, sizeof(stu), 1, fd2);
  }
  fclose(fd1);
  fclose(fd2);
}

void show_students(char filename[]) {
  StudentT stu;
  int j;
  FILE *fd1;
  if ((fd1 = fopen(filename, "rb")) < 0) {
    printf("Cannot open %s for reading. ", filename);
    getchar();
    exit(3);
  }
  j = 0;
  while ( fread(&stu, sizeof(stu), 1, fd1) > 0) {
    printf("\n%d. %-60s %7.2f", j++, stu.name, stu.average);
  }
  fclose(fd1);
}

void cit_stud(char* filename) {
  unsigned int i, n;
  FILE *fd1;
  StudentT stu;
  printf("\nNumber of students in the group= ");
  scanf("%u%*c", &n);
  /* create group file */
  if ((fd1 = fopen(filename, "wb")) < 0) {
    printf("\nCannot create %s. ", filename);
    getchar();
    exit(1);
  }
  /* student data input */
  for (i = 1; i <= n; i++) {
    printf("Name: ");
    gets(stu.name);
    printf("average: ");
    scanf("%f%*c", &stu.average);
    fwrite(&stu, sizeof(stu), 1, fd1);
  }
  fclose(fd1);
}

void add_students(char* filename) {
  FILE *fd1;
  unsigned int i, n;
  StudentT stu;
  /* add new records to file */
  printf("\nNumber of students to add to group= ");
  scanf("%u%*c", &n);
  if ((fd1 = fopen(filename, "ab")) < 0) {
    printf("\nCannot append to %s. ", filename);
    getchar();
    exit(1);
  }
  /* student data input */
  for (i = 1; i <= n; i++) {
    printf("Name: ");
    gets(stu.name);
    printf("average: ");
    scanf("%f%*c", &stu.average);
    fwrite(&stu, sizeof(stu), 1, fd1);
  }
  fclose(fd1);
}

void update_stud(char* filename) {
  int i;
  FILE *fd1;
  long l;
  char ch;
  float avgAux;
  StudentT stu;
  char nameAux[N];
  printf("\nUpdate student info [Yes=Y/y, No=other char]? ");
  ch=getchar();
  fd1 = fopen(filename, "rb+");
  while( toupper(ch) == 'Y') {
    printf("\nStudent number= ");
    scanf("%d%*c", &i);
    l = fseek(fd1, (long)(i * sizeof(StudentT)), SEEK_SET);
    printf("\toffset=%ld for i=%d\n", l, i);
    fread(&stu, sizeof(stu), 1, fd1);
    printf("Current name is: %s New name: ", stu.name);
    gets(nameAux);
    if (*nameAux) strcpy(stu.name, nameAux);
    printf("Current average is: %f\nNew average: ", stu.average);
    scanf("%f%*c", &avgAux);
    if (avgAux > 0 && avgAux <= 10)
      stu.average = avgAux;
    l = fseek(fd1, (long)(i * sizeof(StudentT)), SEEK_SET);
    printf("\toffset=%ld for i=%d\n", l, i);
    fwrite(&stu, sizeof(stu), 1, fd1);
    printf("\nUpdate more student info [Yes=Y/y, No=other char]? ");
    scanf("%c", &ch);
  }
  fclose(fd1);
}

int main() {
  char filename[] = "Group_art.dat";
  char sorted_filename[] = "SortedGroup_art.dat";
  cit_stud(filename);
  printf("\n%s contents after creation\n", filename);
  show_students(filename);
  add_students(filename);
  printf("\n%s contents after addition\n", filename);
  show_students(filename);
  update_stud(filename);
  printf("\n%s contents after changes\n", filename);
  show_students(filename);
  getchar();
  sort(filename, sorted_filename);
  printf("\nGroup sorted by average\n");
  show_students(sorted_filename);
  getchar();
  return 0;
}
